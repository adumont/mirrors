namespace {
/* comment */
somecode(void);  // this is lower case
somecode(void);  // This is UPPER case
somecode(void);  // 1 this is a number
// this is lower case   somecode(void);  
// This is UPPER case   somecode(void);  
// 1 this is a number   somecode(void); 

/* hello */

/* ... *
}