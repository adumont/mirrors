ReadMe.txt  2019 Mar 02

Use Visual Studio 6 to compile Win32For.dsw 

This creates  kernel.bin  which must then be copied to  fKernel.exe  and  Win32For.exe  
in the folder above this one, by running  ExportFiles.bat

Change directory to the folder above this one, you can then run  shell.bat  and them  _MakeAll.bat
to create the final  Win32For.exe  program.