//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by metadlg.rc
//
#define IDD_META                        101
#define IDI_ICON1                       102
#define IDC_CHKOPTCON                   1000
#define IDC_CHKOPTVAR                   1001
#define IDC_CHKNEXT                     1002
#define IDC_RADEXE                      1003
#define IDC_RADDLL                      1004
#define IDC_CHKFIXED                    1005
#define IDC_EDTORIGIN                   1006
#define IDC_BTN_CHKADDR                 1007
#define IDC_EDTMSG                      1008
#define IDC_EDTAPPMEM                   1009
#define IDC_EDTSYSMEM                   1010
#define IDC_EDTCODEMEM                  1011
#define IDC_STATIC                      -1


