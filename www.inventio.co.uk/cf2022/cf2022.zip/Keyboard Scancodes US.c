// File : Keyboard Scancodes US.c  2022 Sep 29

// See also : https://en.wikipedia.org/wiki/Keyboard_layout#Physical,_visual,_and_functional_layouts
// And : https://www.win.tue.nl/~aeb/linux/kbd/scancodes-1.html

// From : http://www.osdever.net/bkerndev/Docs/keyboard.htm

// A keyboard is the most common way for a user to give a computer input, therefore it is vital that
//   you create a driver of some sort for handling and managing the keyboard.
// When you get down to it, getting the basics of the keyboard isn't too bad. Here we will show the basics:
//   how to get a key when it is pressed, and how to convert what's called a 'scancode' to standard ASCII
//   characters that we can understand properly.
// A scancode is simply a key number. The keyboard assigns a number to each key on the keyboard; this is your scancode.
// The scancodes are numbered generally from top to bottom and left to right, with some minor exceptions
//   to keep layouts backwards compatible with older keyboards. You must use a lookup table (an array of values)
//   and use the scancode as the index into this table. The lookup table is called a keymap,
//   and will be used to translate scancodes into ASCII values rather quickly and painlessly.
// One last note about a scancode before we head into code is that if bit 7 is set (test with 'scancode & 0x80'),
//   then this is the keyboard's way of telling us that a key was just released.
// Create yourself a 'kb.h' and do all your standard proceedures like adding a line for GCC and adding a file to LD's command line.

// As you can see, the keyboard will generate an IRQ1 telling us that it has data ready for us to grab.
// The keyboard's data register exists at 0x60. When the IRQ happens, we call this handler which reads from port 0x60.
// This data that we read is the keyboard's scancode. For this example, we check if the key was pressed or released.
// If it was just pressed, we translate the scancode to ASCII, and print that character out with one line.
// Write a 'keyboard_install' function that calls 'irq_install_handler' to install the custom keyboard handler for 'keyboard_handler'
//    to IRQ1. Be sure to make a call to 'keyboard_install' from inside 'main'.
// In order to set the lights on your keyboard, you must send the keyboard controller a command.
// There is a specific proceedure for sending the keyboard a command.
// You must first wait for the keyboard controller to let you know when it's not busy.
// To do this, you read from the Control register (When you read from it, it's called a Status register) in a loop,
//   breaking out when the keyboard isn't busy:
// if ((inportb(0x64) & 2) == 0) break;
// After that loop, you may write the command byte to the Data register.
// You don't write to the control register itself except for in special cases.
// To set the lights on the keyboard, you first send the command byte 0xED using the described method, then you
//    send the byte that says which lights are to be on or off.
//    This byte has the following format: Bit0 is Scroll lock, Bit1 is Num lock, and Bit2 is Caps lock.
// Now that you have basic keyboard support, you may wish to expand upon the code.
// This section on the keyboard was more to show you how to do the basics rather than give an extremely detailed overview
//    of all of the keyboard controller's functions.
// Note that you use the keyboard controller to enable and handle the PS/2 mouse port.
//    The auxilliary channel on the keyboard controller manages the PS/2 mouse.
// Up to this point we have a kernel that can draw to the screen, handle exceptions, handle IRQs, handle the timer,
//    and handle the keyboard.
// Click to find what's next in store for your kernel development.

/* KBDUS means US Keyboard Layout. This is a scancode table
 *  used to layout a standard US keyboard. I have left some
 *  comments in to give you an idea of what key is what, even
 *  though I set it's array index to 0. You can change that to
 *  whatever you want using a macro, if you wish! */
unsigned char kbdus[128] =
{
    0,  27, '1', '2', '3', '4', '5', '6', '7', '8', /* 9 */
    '9', '0', '-', '=', '\b', /* Backspace */
    '\t',         /* Tab */
    'q', 'w', 'e', 'r',   /* 19 */
    't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n', /* Enter key */
    0,          /* 29   - Control */
    'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', /* 39 */
    '\'', '`',   0,        /* Left shift */
    '\\', 'z', 'x', 'c', 'v', 'b', 'n',            /* 49 */
    'm', ',', '.', '/',   0,              /* Right shift */
    '*',
    0,  /* Alt */
    ' ',  /* Space bar */
    0,  /* Caps lock */
    0,  /* 59 - F1 key ... > */
    0,   0,   0,   0,   0,   0,   0,   0,
    0,  /* < ... F10 */
    0,  /* 69 - Num lock*/
    0,  /* Scroll Lock */
    0,  /* Home key */
    0,  /* Up Arrow */
    0,  /* Page Up */
    '-',
    0,  /* Left Arrow */
    0,
    0,  /* Right Arrow */
    '+',
    0,  /* 79 - End key*/
    0,  /* Down Arrow */
    0,  /* Page Down */
    0,  /* Insert Key */
    0,  /* Delete Key */
    0,   0,   0,
    0,  /* F11 Key */
    0,  /* F12 Key */
    0,  /* All other keys are undefined */
};

/* Handles the keyboard interrupt */
void keyboard_handler(struct regs *r)
{
    unsigned char scancode;

    /* Read from the keyboard's data buffer */
    scancode = inportb(0x60);

    /* If the top bit of the byte we read from the keyboard is
     *  set, that means that a key has just been released */
    if (scancode & 0x80)
    {
        /* You can use this one to see if the user released the
         *  shift, alt, or control keys... */
    }
    else
    {
        /* Here, a key was just pressed. Please note that if you
         *  hold a key down, you will get repeated key press
         *  interrupts. */

        /* Just to show you how this works, we simply translate
         *  the keyboard scancode into an ASCII value, and then
         *  display it to the screen. You can get creative and
         *  use some flags to see if a shift is pressed and use a
         *  different layout, or you can add another 128 entries
         *  to the above layout to correspond to 'shift' being
         *  held. If shift is held using the larger lookup table,
         *  you would add 128 to the scancode when you look for it */
        putch(kbdus[scancode]);
    }
}

// From : https://forum.osdev.org/viewtopic.php?f=1&t=11595
// Post subject: Re:PS2 mouse interrupt handler     PostPosted: Sat May 06, 2006 6:00 am
// You could use something like this psudeocode:

void irq1_handler(struct regs *r)
{
    if(r->int_no==1)
    {
        char kb_byte = inb(0x60);
        // etc.
    }
    else if(r->int_no==12)
    {
        char mouse_byte = inb(0x60)
        // etc.
    }
    else
    {
        printf("ERROR");
    }

}

#if( 0 )

// UNTESTED!!!

unsigned char kbdus[128] =
{
    0,                      // 0x00 
    27,                     // 0x01   Escape
    '1', '2', '3', '4',     // 0x02 to 05
    '5', '6', '7', '8',     // 0x06 to 09
    '9', '0', '-', '=',     // 0x0A to 0D
    '\b',                   // 0x0E   Backspace
    '\t',                   // 0x0F   Tab
    'q', 'w', 'e', 'r',     // 0x10 to 13
    't', 'y', 'u', 'i',     // 0x14 to 17
    'o', 'p', '[', ']',     // 0x18 to 1C
    '\n',                   // 0x1D Enter key
    0,                      // 0x1E                   // 29   - Control
    'a', 's', 'd', 'f',     // 0x1F to 22
    'g', 'h', 'j', 'k',     // 0x23 to 26 
    'l', ';', '\'', '`',    // 0x27 to 2A
    0,                      // 0x2B Left shift
    '\\', 'z', 'x', 'c',    // 0x2C to 2F
    'v', 'b', 'n', 'm',     // 0x30 to 33             // 49
    ',', '.', '/',          // 0x34 to 36
    0,                      // 0x37   Right shift
    '*',                    // 0x38   
    0,                      // 0x39   Alt
    ' ',                    // 0x3A   Space bar
    0,                      // 0x3B   Caps lock
    0,                      // 0x3C                   // 59 - F1 key ... >
    0,   0,   0,   0,       // 0x3D to 0x40
    0,   0,   0,   0,       // 0x41 to 0x44
    0,                      // 0x45  < ... F10
    0,                      // 0x46                   // 69 - Num lock
    0,                      // 0x47  Scroll Lock
    0,                      // 0x48  Home key
    0,                      // 0x49  Up Arrow
    0,                      // 0x4A  Page Up
    '-',                    // 0x4B  
    0,                      // 0x4C  Left Arrow
    0,                      // 0x4D   
    0,                      // 0x4E  Right Arrow
    '+',                    // 0x4F   
    0,                      // 0x50                   // 79 - End key
    0,                      // 0x51  Down Arrow
    0,                      // 0x52  Page Down
    0,                      // 0x53  Insert Key
    0,                      // 0x54  Delete Key
    0,   0,   0,            // 0x55   
    0,                      // 0x56  F11 Key
    0,                      // 0x57  F12 Key
    0,                      // 0x58  All other keys are undefined
};


// From cf2022.nasm 2022Sep28
// qwerty_key_map_table:   ; table to convert Scancode to ASCII (?) value
// ;         0     1     2     3     4     5     6     7     8     9     A     B     C     D     E     F
//     db 0x0B, 0x18, 0x02, 0x19, 0x03, 0x1A, 0x04, 0x1B, 0x05, 0x1C, 0x06, 0x1D, 0x07, 0x1E, 0x08, 0x1F ; 0x00
//     db 0x09, 0x20, 0x0A, 0x21, 0x1e, 0x05, 0x30, 0x13, 0x2E, 0x0A, 0x20, 0x10, 0x12, 0x04, 0x21, 0x0E ; 0x10
//     db 0x22, 0x0D, 0x23, 0x14, 0x17, 0x07, 0x24, 0x22, 0x25, 0x24, 0x26, 0x0C, 0x32, 0x09, 0x31, 0x06 ; 0x20
//     db 0x18, 0x03, 0x19, 0x12, 0x10, 0x17, 0x13, 0x01, 0x1F, 0x08, 0x14, 0x02, 0x16, 0x16, 0x2F, 0x11 ; 0x30
//     db 0x11, 0x0F, 0x2D, 0x15, 0x15, 0x0B, 0x2C, 0x26, 0x0C, 0x23, 0x34, 0x25, 0x35, 0x27, 0x27, 0x28 ; 0x40
//     db 0x28, 0x29, 0x82, 0x2A, 0x8D, 0x2B, 0x83, 0x2C, 0x89, 0x2D, 0x33, 0x2E, 0xB5, 0x2F, 0x39, 0x80 ; 0x50
//     db 0x1C, 0x81, 0x0E, 0x82, 0x01, 0x83, 0x3B, 0x84, 0x29, 0x30, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F ; 0x60
//     db 0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F ; 0x70

The scancodes in translated scancode set 2 are given in hex. Between parentheses the keycap on a US keyboard. The scancodes are given in order, grouped according to groups of keys that are usually found next to each other.

// Hex values :
00 is normally an error code
01 (Esc)
02 (1!), 03 (2@), 04 (3#), 05 (4$), 06 (5%E), 07 (6^), 08 (7&), 09 (8*), 0a (9(), 0b (0)), 0c (-_), 0d (=+), 0e (Backspace)
0f (Tab), 10 (Q), 11 (W), 12 (E), 13 (R), 14 (T), 15 (Y), 16 (U), 17 (I), 18 (O), 19 (P), 1a ([{), 1b (]})
1c (Enter)
1d (LCtrl)
1e (A), 1f (S), 20 (D), 21 (F), 22 (G), 23 (H), 24 (J), 25 (K), 26 (L), 27 (;:), 28 ('")
29 (`~)
2a (LShift)
2b (\|), on a 102-key keyboard
2c (Z), 2d (X), 2e (C), 2f (V), 30 (B), 31 (N), 32 (M), 33 (,<), 34 (.>), 35 (/?), 36 (RShift)
37 (Keypad-*) or (*/PrtScn) on a 83/84-key keyboard
38 (LAlt), 39 (Space bar),
3a (CapsLock)
3b (F1), 3c (F2), 3d (F3), 3e (F4), 3f (F5), 40 (F6), 41 (F7), 42 (F8), 43 (F9), 44 (F10)
45 (NumLock)
46 (ScrollLock)
47 (Keypad-7/Home), 48 (Keypad-8/Up), 49 (Keypad-9/PgUp)
4a (Keypad--)
4b (Keypad-4/Left), 4c (Keypad-5), 4d (Keypad-6/Right), 4e (Keypad-+)
4f (Keypad-1/End), 50 (Keypad-2/Down), 51 (Keypad-3/PgDn)
52 (Keypad-0/Ins), 53 (Keypad-./Del)
54 (Alt-SysRq) on a 84+ key keyboard
55 is less common; occurs e.g. as F11 on a Cherry G80-0777 keyboard, as F12 on a Telerate keyboard, as PF1 on a Focus 9000 keyboard, and as FN on an IBM ThinkPad.
56 mostly on non-US keyboards. It is often an unlabelled key to the left or to the right of the left Alt key.



#endif

// end of file
