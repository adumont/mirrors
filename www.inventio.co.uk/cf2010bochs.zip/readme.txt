Real colorForth running really slowly... 2010 Jun 08

A tradeoff between working on (just about) any Windows PC against execution speed.

Double left click ( run ) go.bat to start the cf2010.blk version of colorForth
in a bochs PC emulator. 
bochs is available from http://bochs.sourceforge.net/
bochs is truly wonderful! Thank you to all the bochs developers...

Howerd Oakford  www.inventio.co.uk
