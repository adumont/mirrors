Real colorForth running slowly... 2012 Oct 21

A tradeoff between working on (just about) any Windows PC against execution speed.

Double left click ( run ) go.bat to start the cf2012.img version of colorForth ( in the folder one level up )
in a bochs PC emulator. 
bochs is available from http://bochs.sourceforge.net/
bochs is truly wonderful! Thank you to all the bochs developers...

Howerd Oakford  www.inventio.co.uk
