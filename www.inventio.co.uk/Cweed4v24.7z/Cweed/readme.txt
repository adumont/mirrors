Cweed V4.24 2020 Nov 13

Run  go.bat  to recompile using the supplied Win32Forth V6.05H (with Win7/8/10 support)

Configuration options are at the top of the file Cweed.f
File parsing is in files.f

Run Cweed.exe and select the file to tidy up. press F1 for Help.

Enjoy!
Howerd Oakford www.inventio.co.uk

New in V4.24 
Now packaged with Win32Forth6v05H 2019 Mar 02 which fixes a bug that forced its window to be too small.

New in V4.23 
Indenting now ignores #ifdef, #ifndef, #else and #endif if the line contains double underscores : __IGNORE_THISE_INDENT__
This is to prevent indentation in *.h files with the usual redefinition macro format, below.
Please make sure any #else and #endif has a double underscore in a comment on the same line :

#ifndef __HEADER_FILE_NAME__
#define __HEADER_FILE_NAME__

 ... your code here...

#endif // __HEADER_FILE_NAME__

New in V4.2
 �Select File� now defaults to All Files *.*,made INDENT_SPACES changeable.

New in V4.1 :
 NumName.f Howerd Oakford V1.0 2012 Feb 28  Win32Forth version  www.inventio.co.uk
 Display a 15 bit number (from 0 to 32767) as an English word, and two 15 bit numbers as a pair of words.
 The two-word phrase calculated from the checksum or hash of two different files has a roughly 1 in a billion chance of being the same
 This allows two files in different locations and/or times to be compared by human beings...
 This code requires the file NumName.txt in the same folder