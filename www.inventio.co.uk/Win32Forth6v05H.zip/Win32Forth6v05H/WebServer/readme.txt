These files are copied from Win32Forth V6.14 - they need to be ported back to V6.05 ... sorry no time to do that yet...Howerd :-)
