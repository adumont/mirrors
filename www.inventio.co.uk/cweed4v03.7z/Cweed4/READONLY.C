/* 1 one
2 //   two
3    three */
4    four
5    five
6 // six  /*
7    seven /* */
//8  t_struct* fred;
9
10 int a = b +
11 * z;
12
13 t_struct *fred;
14
15 0123456789sdafasfdasf
16 t_struct *fred;
17 The end
18
19
20
21
22
23
24
25
26
27
28
29
30
31
