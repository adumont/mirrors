USBloader   2013 Apr 08

The USBloader system is designed to make it easy to make any USB disk drive bootable.

This allows you to run your choice of operating system on your computer, from a USB drive.

Program execution is in Real Mode on an 80x86 PC, 80386 32 bit or higher is required.

USBloader supersedes USBboot which is no longer supported.

Download  : 

USBloader2013Apr08release.exe  self extracting zip file or  USBloader2013Apr08release.zip zip file.

Disclaimer : using USBloader.exe to make a USB drive bootable should not affect the other files on the drive.
Use it at your own risk, and backup up everything on your drive, or use a brand new one, just in case�

Now with new Floppy Disk Formatting features : press ctrlF4 to convert the cfUSB.img file into a floppy disk image and copy it to the inserted drive. This can be either a USB floppy disk drive or USB drive, in either case the disk will be re-formatted and all data will be lost. 
There are two warnings before this happens�

Go to the directory where you unzipped the files and follow the instructions in the readme.txt file, or below :

How To
1.	Double-click * on USBloader.exe , insert a USB drive to be made bootable, press Q and Y .
2.	Copy the file KERNEL.IMG onto the USB drive using Windows or DOS, or by removing and re-inserting the USB drive and pressing K and Y .
3.	Restart the computer � it will now boot from the program KERNEL.IMG on the USB drive.
 
The computer�s BIOS must be configured to boot from a USB drive � please see http://www.ehow.com/how_7245683_configure-bios-boot-usb.html 
or Google for how to do this.

* Note : for Windows 7 and 8 you must right-click on USBloader.exe and select �Run as administrator�  to allow access to the USB drive.
Overview
The USBloader system consists of three files :  

1.	USBloader.exe   a Windows program to read and write USB disk drives
2.	cfUSB.img       a binary image of a FAT32 bootloader program
cfUSB contains :
3.	KERNEL.IMG      a binary image of a �Hello World� test program

If a computer is powered up with a bootable USB drive connected, and if the computer�s BIOS has been configured to allow booting from a USB drive, the bootloader program (cfUSB.img) on the USB drive will be run. 
The supplied bootloader program cfUSB.img will then run the file KERNEL.IMG ( contained within cfUSB.img ) from the USB drive.
USBloader.exe

USBloader.exe waits for a USB disk drive to be inserted, analyses its contents, and gives the option to copy the 
file cfUSB.img to the USB drive�s boot sector. 
USBloader.exe is a Windows program compiled using SwiftForth from www.forth.com .
The following files are used to create USBloader.exe :
1.       USBloader.f             main load file
2.       CapturedMBRsectors.f  some real MBR sectors, used to name your MBR
3.       DirectoryDisplay.f    defines the FAT32 directory structure
4.       FormatFAT32.f         creates a Floppy Disk image file, formatted with a FAT32 system containing KERNEL.IMG 
5.       LogToFile.f           saves screen output to a file
6.       md5.f                 the MD5 hash calculation, used to describe binary files
7.       NumName.f             displays and MD5 hash as an English word-pair
8.       ReadFileFAT32.f       defines how to read a file in a FAT32 file system
9.       NumName.f also uses NumName.txt for the list of English words.

To recompile USBloader.exe run SwiftForth, change to the USBloader directory and type 
Include USBloader

cfUSB.img
cfUSB.img is a FAT32 file system boot loader program, assembler together with an application program. 
cfUSB.img is an assembler program compiled using NASM from http://www.nasm.us/
The batch file go.bat will run nasm.exe ( provided ) and assemble cfUSB.nasm to create cfUSB.img .
It also copies the new cfUSB.img to the USBloader folder, for use by USBloader.exe .
Open a Windows command window ( run cmd.exe ), change directory to cfUSB\nasm and type
go
The BPB boot sector ( sector 0 ) of cfUSB.img scans the FAT32 file system within cfUSB.img , for the file KERNEL.IMG and if found, 
copies it into memory at 0x7D00 and executes it.
The USBloader.exe program automatically splits cfUSB.img into the BPB boot sector and the rest of the image file, KERNEL.IMG .
KERNEL.IMG
KERNEL.IMG is a Real Mode program to run on an 80x86 based PC. 
It must run from segment 0x0000 offset 0x7D00 ( address 0x7D00 ) in memory in Real Mode.
It is loaded into memory contiguously with the BPB boot loader which is loaded by the BIOS into memory at $7C00.
This means that NASM creates one file, the first sector of which is the BPB boot loader, and the rest if the KERNEL.IMG application program.
KERNEL.IMG is an assembler program compiled using NASM from http://www.nasm.us/ as part of cfUSB.img .

The batch file go.bat will run nasm.exe ( provided ) and assemble cfUSB.nasm to create cfUSB.IMG .
The USBloader.exe program automatically splits cfUSB.img into the BPB boot sector and the rest of the image file, KERNEL.IMG .

USBloader is designed to allow colorForth or another operating system to be run from a USB drive.
Enjoy!
Howerd Oakford  www.inventio.co.uk
