(t_struct *)fred; OK
t_struct *fred    OK
(t_struct *)fred; OK
(t_struct *) fred; OK
(t_struct* )fred;
(t_struct*) fred;
t_struct* fred; t_struct *fred; e_struct* fred;
t_struct * fred; e_struct *fred;
(t_struct*)fred;
t_struct * fred;

3. /* ignore this comment */But not this
5. But not this line
8. some     t   a   b   s
t_struct fred;

t_struct  f r   e   d;
t_struct  fred;/* */

int a = b +
* z;


0123456789sdafasfdasf
t_struct *fred;
The end.
