//..begin "FILE DESCRIPTION"
//----------------------------------------------------------------------
//      (C) Copyright Landis+Gyr Enermet OY, CH-Zug & FI-Jysk�, 2007-2015
//      Use or copying of all or any part of the document, except
//      as permitted by the License Agreement is prohibited.
//----------------------------------------------------------------------
//
//      Purpose   : ANSI Implementation File
//      Package   : ASN.1 Abstract Syntax Notation version 1 parser
//      File name : ParseCertificate.c
//      Status    :
//
//----------------------------------------------------------------------
//..end "FILE DESCRIPTION"
 
// Parse a Certificate that uses ASN.1 Abstract Syntax Notation version 1 and DER Distinguished Encoding Rules   2015 Mar 09
// DER = BER Basic Encoding Rules with special extra rules : 
// the length format must be the smallest possible, cannot be an indefinite length, attributes will always be in the same order, etc.
// For simple string types and implicitly tagged types derived from simple string types, the primitive, definite-length method must be employed.
// For structured types, implicitly tagged types derived from structured types, and explicitly tagged types derived from anything, the constructed, 
// definite-length method must be employed. From : http://luca.ntop.org/Teaching/Appunti/asn1.html
// ( A Layman's Guide to a Subset of ASN.1, BER, and DER, An RSA Laboratories Technical Note, Burton S. Kaliski Jr., Revised November 1, 1993 )
// A certificate follows X.509 : http://en.wikipedia.org/wiki/X.509  http://tools.ietf.org/html/rfc3280  https://www.ietf.org/rfc/rfc2459.txt
// Encoded using ASN.1 and DER : http://en.wikipedia.org/wiki/X.690
// signature algorithms        : https://tools.ietf.org/html/rfc5758
// Object IDentifiers          : http://oid-info.com/index.htm   https://docs.oracle.com/javame/8.0/api/gcf/api/javax/microedition/pki/Certificate.html

#include "BaseTypes.h"

typedef unsigned char U8 ;
typedef unsigned short U16 ; 

#include "ParseCertificate.h"
#include <string.h>


// OID values encode the first 2 values in the first octet so the decimal dot form 2.5.4.11 --> 55 04 0B
// To find the meaning of an OID, decode the OID string (see below) and go to http://oid-info.com/

// From : http://luca.ntop.org/Teaching/Appunti/asn1.html :
// The first octet has value 40 * value1 + value2. 
// (This is unambiguous, since value1 is limited to values 0, 1, and 2; value2 is limited to the range 0 to 39 when value1 is 0 or 1; and, according to X.208, n is always at least 2.)
// The following octets, if any, encode value3, ..., valuen. 
// Each value is encoded base 128, most significant digit first, with as few digits as possible, 
// and the most significant bit of each octet except the last in the value's encoding set to "1."
// Example: The first octet of the BER encoding of RSA Data Security, Inc.'s object identifier is
// 40 * 1 + 2 = 42 = 2a16. 
// The encoding of 840 = 6 * 128 + 0x48 is 86 48 and the encoding of 113549 = 6 * 1282 + 0x77 * 128 + 0x0d is 86 f7 0d. 
// This leads to the following BER encoding:
// 06 06 2a 86 48 86 f7 0d

// Note : we do not need to decode the Certificate OIDs - we just compare them to the pre-encoded strings below - above is for information only.
// Note : the first octet of each string below is its length.

/* 
// The Object Identifiers ( OIDs ) used in an X.509 Certificate
// Information from http://oid-info.com/           | length | .....hex octets.....         | dot form |
const U8 OID_id_at_organizationUnitName       [] = { 0x03u , 0x55u , 0x04u , 0x0Bu };     // 2.5.4.11 OU organizationUnitName  Annex A of Rec. ITU-T X.520 (February 2001) and in ISO/IEC 9594-6: 2001: "The Directory: Selected attribute types". 
const U8 OID_id_at_commonName                 [] = { 0x03u , 0x55u , 0x04u , 0x03u };     // 2.5.4.3  CN Rec. ITU-T X.520 | ISO/IEC 9594-6 "The Directory: Selected attribute types". 
const U8 OID_uniqueIdentifier                 [] = { 0x03u , 0x55u , 0x04u , 0x2Du };     // 2.5.4.45 uniqueIdentifier  Annex A of Rec. ITU-T X.520 (February 2001) and in ISO/IEC 9594-6: 2001: "The Directory: Selected attribute types
                                                                              
const U8 OID_X509v3_SubjectKeyIdentifier      [] = { 0x03u , 0x55u , 0x1Du , 0x0Eu };     // 2.5.29.14 subjectKeyIdentifier X509v3
const U8 OID_X509v3_CertificatePolicies       [] = { 0x03u , 0x55u , 0x1Du , 0x20u };     // 2.5.29.32 certificatePolicies X509v3 
const U8 OID_X509v3_AuthorityKeyIdentifier    [] = { 0x03u , 0x55u , 0x1Du , 0x23u };     // 2.5.29.35 authorityKeyIdentifier X509v3 
const U8 OID_X509v3_KeyUsage                  [] = { 0x03u , 0x55u , 0x1Du , 0x0Fu };     // 2.5.29.15 keyUsage X509v3 
const U8 OID_X509v3_SubjectAlternativeName    [] = { 0x03u , 0x55u , 0x1Du , 0x11u };     // 2.5.29.17 subjectAltName X509v3 
const U8 OID_X509v3_BasicConstraints          [] = { 0x03u , 0x55u , 0x1Du , 0x13u };     // 2.5.29.19 basicConstraints X509v3 

const U8 OID_id_ecPublicKey                   [] = { 0x07u , 0x2Au , 0x86u , 0x48u , 0xCEu , 0x3Du , 0x02u , 0x01u };           // 1.2.134.72.206.61.2.1   id-ecPublicKey
const U8 OID_ecdsa_with_SHA256                [] = { 0x08u , 0x2Au , 0x86u , 0x48u , 0xCEu , 0x3Du , 0x04u , 0x03u , 0x02u };   // 1.2.134.72.206.61.4.3.2 ecdsa-with-SHA256
const U8 OID_NegTokenInit                     [] = { 0x08u , 0x2Bu , 0x06u , 0x01u , 0x05u , 0x05u , 0x07u , 0x01u , 0x14u };   // 1.3.6.1.5.5.7.1.20      NegTokenInit
*/

// we only use these two OIDs at the moment :
const U8 OID_secp256r1_prime256v1_7           [] = { 0x08u , 0x2Au , 0x86u , 0x48u , 0xCEu , 0x3Du , 0x03u , 0x01u , 0x07u };   // 1.2.134.72.206.61.3.1.7 secp256r1/prime256v1(7)
const U8 OID_X509v3_AuthorityKeyIdentifier    [] = { 0x03u , 0x55u , 0x1Du , 0x23u };     // 2.5.29.35 authorityKeyIdentifier X509v3 

#define ASN1_OID 0x06u

// access the given Certificate as a stream of octets
U8 *PayloadDataStart;    // points to the start of the Certificate
U8 PayloadDataOffset;    // the offset in the Certificate of the current octet being read
U16 PayloadDataLength;   // the length of the Certificate being parsed

// get the next octet in the Certificate input stream
U8 PayloadDataGetCh ( void )
{
   return( PayloadDataStart[ PayloadDataOffset++ ] );
}

// The special ASN.1 variable-length encoded length
U16 ASNoneGetLengthLimited ( void )
{
   U8 MyChar;
   U16 MyLength;

   MyChar = PayloadDataGetCh();
   MyLength = (U16)MyChar;
   
   if( MyChar & 0x80 )
   {
      switch( MyChar ) 
      { 
//       case  0x80 of  -1  endof    // indefinite length, terminated by and EOC with 0 length ( two 0's ) Note : not allowed by DER rules
         case 0x81 :   MyLength = (U16)PayloadDataGetCh(); break;
         case 0x82 :   MyLength = ( ( (U16)PayloadDataGetCh() << 8 ) | (U16)PayloadDataGetCh() ); break; 
//       case 0x83 :   ( ( (U16)PayloadDataGetCh() << 16 ) | ( (U16)PayloadDataGetCh() << 8 ) | (U16)PayloadDataGetCh() ); break;  // Note : not required, as Certificates will always be < 32767 octets
         default:  MyLength = 0;  /* fatal error */  break;
      }
   }
   return( MyLength );
}

// variables to sae the state of the parser
U16 CurrentTag;               // the current Tag's type
U16 CurrentTagOffset;            // pointer to the start of the current Tag's Value field
U16 CurrentTagLength;         // The current Tag's value's length
U16 FoundRequiredOID;         // set true when the required OID is found

// move the data pointer past the current Tag's value field
void SkipValue ( void )
{
   PayloadDataOffset += CurrentTagLength;
}

void GetTagAndLength( void )
{
   CurrentTag = PayloadDataGetCh();   
   CurrentTagLength = ASNoneGetLengthLimited();
}

void GetNextTLV( void )
{
   SkipValue();                // skip the current Tag's value
   GetTagAndLength();                   // load the next Tag
   CurrentTagOffset = PayloadDataOffset;   // mark the offset of the current Tag's value field
}

void GetTagLengthValue ( U8 * RequiredOID )
{
   GetTagAndLength();

   U8 * RequiredOIDaddress;
   U16 RequiredOIDlength;

   RequiredOIDlength = (U16)RequiredOID[ 0 ];
   RequiredOIDaddress = RequiredOID + 1;

   if( 0 == ( CurrentTag & 0x20 ) )     // primitive packet, contains real data to check and/or skip. A ConstructedPacket has no data, just the length of SEQUENCE or SET.
   {
      if( ASN1_OID == ( CurrentTag & 0x3F ) )
      {
         if( RequiredOIDlength == CurrentTagLength )
         {
            if( 0 == ( memcmp( RequiredOIDaddress , &PayloadDataStart[ PayloadDataOffset ] , CurrentTagLength ) ) )
            {
               GetNextTLV();
               FoundRequiredOID = 0x0001u;
            }
         }
      }
      if( !FoundRequiredOID )
      {
         SkipValue();
      }
   }
} 

// given the address and Length of a Certificate and the required OID, returns the OIDoffset in the Certificate and its length
// SkipOctets is the number of octets that must be skipped to get to the required value.
// Please see the functions below that use Certificate_getOID() for more details.
U16 Certificate_getOID( U8 * Certificate , U16 CertificateLength , U8 *RequiredOID , U16 *OIDoffset, U16 *OIDlength , U16 SkipOctets )
{ 
   U16 result;

   PayloadDataStart = Certificate;  // setup the start of the Certificate
   PayloadDataOffset = 0;           // point to the first octet
   
   FoundRequiredOID = 0;            // not found the required Object Identifier yet

   while( ( CertificateLength > PayloadDataOffset ) && ( 0 == FoundRequiredOID ) )  // run until the end of the certificate is reached, or the OID has been found
   {
      GetTagLengthValue( RequiredOID );  
   };
   
   if( 0 == FoundRequiredOID )      // not found
   {
      result = 0x0001u;             // return error flag
   }
   else
   {
      *OIDoffset = CurrentTagOffset + SkipOctets ;
      *OIDlength = CurrentTagLength - SkipOctets ;
      result = 0x0000u;  // return success flag
   }
   
   return( result );  
}

// Gets the certificate's Public Key
// There is only one OID_secp256r1_prime256v1_7 OID in a Certificate ( which always follows the OID_id_ecPublicKey ) 
// The required OID's value is the first Tag following OID_secp256r1_prime256v1_7
// The PublicKey value follows the initial BitString octet and a value of 0x04, so skip 0x02u octets
U16 Certificate_getPublicKey( U8 *Certificate , U16 CertificateLength , U16 *OIDoffset, U16 *OIDlength )
{
   return( Certificate_getOID ( Certificate , CertificateLength, (U8*)OID_secp256r1_prime256v1_7 , OIDoffset , OIDlength , 0x02u ) );
}

// Gets the certificate's AuthorityKeyIdentifier ( Originator ID )
// There is only one OID_X509v3_AuthorityKeyIdentifier in a Certificate 
// The required OID's value is the first Tag following it
// X509v3_AuthorityKeyIdentifier := 
// 0000  30 Universal        C SEQUENCE                                    A
//     0002  80 Context-specific P EOC (End-of-Content)                    8 | 4B 62 32 39 E2 3C D6 C7  ok
// The  AuthorityKeyIdentifier value follows a Sequence|Length pair and Context-specific P EOC (End-of-Content) Sequence|Length pair , so skip 0x04u octets
// This assumes that the OID_X509v3_AuthorityKeyIdentifier is less thatn ( 127 - 4 ) octets long, which is always the case.
U16 Certificate_getAuthorityKeyIdentifier( U8 *Certificate , U16 CertificateLength , U16 *OIDoffset, U16 *OIDlength )
{
   return( Certificate_getOID ( Certificate , CertificateLength, (U8*)OID_X509v3_AuthorityKeyIdentifier , OIDoffset , OIDlength , 0x04u ) );
}

U8 ResultBuffer1[ 0x100 ];
U8 ResultBuffer2[ 0x100 ];

const U8 MytestArray_ICA_OrgCA_der[ 0x1A2u ] = {
    0x30u , 0x82u , 0x01u , 0x9Eu , 0x30u , 0x82u , 0x01u , 0x44u , 0xA0u , 0x03u , 0x02u , 0x01u , 0x02u , 0x02u , 0x10u , 0x10u ,
    0x00u , 0x00u , 0x00u , 0x00u , 0x00u , 0x00u , 0x01u , 0x10u , 0x00u , 0x00u , 0x00u , 0x00u , 0x00u , 0x00u , 0x02u , 0x30u ,
    0x0Au , 0x06u , 0x08u , 0x2Au , 0x86u , 0x48u , 0xCEu , 0x3Du , 0x04u , 0x03u , 0x02u , 0x30u , 0x1Au , 0x31u , 0x0Bu , 0x30u ,
    0x09u , 0x06u , 0x03u , 0x55u , 0x04u , 0x0Bu , 0x0Cu , 0x02u , 0x30u , 0x30u , 0x31u , 0x0Bu , 0x30u , 0x09u , 0x06u , 0x03u ,
    0x55u , 0x04u , 0x03u , 0x0Cu , 0x02u , 0x46u , 0x46u , 0x30u , 0x1Eu , 0x17u , 0x0Du , 0x31u , 0x35u , 0x30u , 0x31u , 0x30u ,
    0x37u , 0x30u , 0x39u , 0x32u , 0x30u , 0x35u , 0x30u , 0x5Au , 0x17u , 0x0Du , 0x34u , 0x30u , 0x30u , 0x31u , 0x30u , 0x38u ,
    0x30u , 0x39u , 0x32u , 0x30u , 0x35u , 0x30u , 0x5Au , 0x30u , 0x1Au , 0x31u , 0x0Bu , 0x30u , 0x09u , 0x06u , 0x03u , 0x55u ,
    0x04u , 0x0Bu , 0x0Cu , 0x02u , 0x30u , 0x37u , 0x31u , 0x0Bu , 0x30u , 0x09u , 0x06u , 0x03u , 0x55u , 0x04u , 0x03u , 0x0Cu ,
    0x02u , 0x46u , 0x46u , 0x30u , 0x59u , 0x30u , 0x13u , 0x06u , 0x07u , 0x2Au , 0x86u , 0x48u , 0xCEu , 0x3Du , 0x02u , 0x01u ,
    0x06u , 0x08u , 0x2Au , 0x86u , 0x48u , 0xCEu , 0x3Du , 0x03u , 0x01u , 0x07u , 0x03u , 0x42u , 0x00u , 0x04u , 0xFFu , 0x8Du ,
    0xB1u , 0xECu , 0xFBu , 0x5Eu , 0x7Du , 0xB3u , 0x70u , 0x22u , 0x58u , 0x32u , 0x1Du , 0x28u , 0xF8u , 0x3Bu , 0xD4u , 0x91u ,
    0x00u , 0x91u , 0x5Fu , 0x08u , 0x43u , 0x81u , 0x47u , 0x91u , 0x6Fu , 0x7Fu , 0x69u , 0x6Au , 0x87u , 0xC7u , 0x57u , 0x66u ,
    0x6Eu , 0xD4u , 0x59u , 0x16u , 0x6Eu , 0x81u , 0x19u , 0x5Au , 0x3Au , 0x68u , 0x6Eu , 0x9Fu , 0x4Eu , 0xD3u , 0xC5u , 0x56u ,
    0xB1u , 0x24u , 0xF8u , 0x26u , 0x28u , 0xD9u , 0x3Eu , 0x2Eu , 0x57u , 0x7Du , 0xC0u , 0x2Fu , 0x07u , 0xE1u , 0xA3u , 0x6Cu ,
    0x30u , 0x6Au , 0x30u , 0x11u , 0x06u , 0x03u , 0x55u , 0x1Du , 0x0Eu , 0x04u , 0x0Au , 0x04u , 0x08u , 0x49u , 0x6Bu , 0x2Du ,
    0x04u , 0xD2u , 0x90u , 0x4Eu , 0xD2u , 0x30u , 0x13u , 0x06u , 0x03u , 0x55u , 0x1Du , 0x23u , 0x04u , 0x0Cu , 0x30u , 0x0Au ,
    0x80u , 0x08u , 0x4Bu , 0x62u , 0x32u , 0x39u , 0xE2u , 0x3Cu , 0xD6u , 0xC7u , 0x30u , 0x12u , 0x06u , 0x03u , 0x55u , 0x1Du ,
    0x13u , 0x01u , 0x01u , 0xFFu , 0x04u , 0x08u , 0x30u , 0x06u , 0x01u , 0x01u , 0xFFu , 0x02u , 0x01u , 0x00u , 0x30u , 0x1Cu ,
    0x06u , 0x03u , 0x55u , 0x1Du , 0x20u , 0x01u , 0x01u , 0xFFu , 0x04u , 0x12u , 0x30u , 0x10u , 0x30u , 0x0Eu , 0x06u , 0x0Cu ,
    0x2Au , 0x86u , 0x3Au , 0x00u , 0x01u , 0xEDu , 0xEEu , 0x40u , 0x01u , 0x02u , 0x01u , 0x02u , 0x30u , 0x0Eu , 0x06u , 0x03u ,
    0x55u , 0x1Du , 0x0Fu , 0x01u , 0x01u , 0xFFu , 0x04u , 0x04u , 0x03u , 0x02u , 0x01u , 0x06u , 0x30u , 0x0Au , 0x06u , 0x08u ,
    0x2Au , 0x86u , 0x48u , 0xCEu , 0x3Du , 0x04u , 0x03u , 0x02u , 0x03u , 0x48u , 0x00u , 0x30u , 0x45u , 0x02u , 0x20u , 0x77u ,
    0xEAu , 0x09u , 0x85u , 0x83u , 0x89u , 0xC9u , 0x6Fu , 0x0Au , 0xC4u , 0xF5u , 0x05u , 0x72u , 0xA6u , 0xADu , 0x78u , 0x4Bu ,
    0xD4u , 0xEEu , 0x8Au , 0x02u , 0x90u , 0xEFu , 0x26u , 0xEAu , 0x0Cu , 0x13u , 0xB8u , 0xFEu , 0xA9u , 0x5Au , 0xF7u , 0x02u ,
    0x21u , 0x00u , 0xA5u , 0xD1u , 0x2Eu , 0x11u , 0xCDu , 0x47u , 0x91u , 0x40u , 0x00u , 0x4Du , 0x2Eu , 0x77u , 0x57u , 0xE7u ,
    0x59u , 0xACu , 0x40u , 0x70u , 0xA6u , 0xAFu , 0x09u , 0x2Au , 0x93u , 0xD1u , 0x91u , 0xA7u , 0x53u , 0x6Cu , 0xEDu , 0xAFu ,
    0x35u , 0x4Eu 
};

void TestParseCertificate( void )
{
   U16 ResultOffset;
   U16 ResultLength;
   U16 i;
   
   // clear the result buffers
   for( i = 0 ; i < 0x100 ; i++ )
   {
      ResultBuffer1[ i ] = 0;
      ResultBuffer2[ i ] = 0;
   }

   Certificate_getPublicKey( (U8*)MytestArray_ICA_OrgCA_der , 0x1A2u , &ResultOffset , &ResultLength );
   ResultBuffer1[ 0 ] = (U8)ResultLength;
   for( i = 0 ; i < ResultLength ; i++ )
   {
      ResultBuffer1[ i + 1 ] = MytestArray_ICA_OrgCA_der[ ResultOffset + i ];      
   }

   Certificate_getAuthorityKeyIdentifier( (U8*)MytestArray_ICA_OrgCA_der , 0x1A2u , &ResultOffset , &ResultLength );
   ResultBuffer2[ 0 ] = (U8)ResultLength;
   for( i = 0 ; i < ResultLength ; i++ )
   {
      ResultBuffer2[ i + 1 ] = MytestArray_ICA_OrgCA_der[ ResultOffset + i ];      
   }  
}

/* From : https://www.ietf.org/rfc/rfc2459.txt 
Basic Certificate Fields

   The X.509 v3 certificate basic syntax is as follows.  For signature
   calculation, the certificate is encoded using the ASN.1 distinguished
   encoding rules (DER) [X.208].  ASN.1 DER encoding is a tag, length,
   value encoding system for each element.

   Certificate  ::=  SEQUENCE  {
        tbsCertificate       TBSCertificate,
        signatureAlgorithm   AlgorithmIdentifier,
        signatureValue       BIT STRING  }

   TBSCertificate  ::=  SEQUENCE  {
        version         [0]  EXPLICIT Version DEFAULT v1,
        serialNumber         CertificateSerialNumber,
        signature            AlgorithmIdentifier,
        issuer               Name,
        validity             Validity,
        subject              Name,
        subjectPublicKeyInfo SubjectPublicKeyInfo,
        issuerUniqueID  [1]  IMPLICIT UniqueIdentifier OPTIONAL,
                             -- If present, version shall be v2 or v3
        subjectUniqueID [2]  IMPLICIT UniqueIdentifier OPTIONAL,
                             -- If present, version shall be v2 or v3
        extensions      [3]  EXPLICIT Extensions OPTIONAL
                             -- If present, version shall be v3
        }

   Version  ::=  INTEGER  {  v1(0), v2(1), v3(2)  }

   CertificateSerialNumber  ::=  INTEGER

   Validity ::= SEQUENCE {
        notBefore      Time,
        notAfter       Time }

   Time ::= CHOICE {
        utcTime        UTCTime,
        generalTime    GeneralizedTime }

   UniqueIdentifier  ::=  BIT STRING

   SubjectPublicKeyInfo  ::=  SEQUENCE  {
        algorithm            AlgorithmIdentifier,
        subjectPublicKey     BIT STRING  }

   Extensions  ::=  SEQUENCE SIZE (1..MAX) OF Extension

   Extension  ::=  SEQUENCE  {
        extnID      OBJECT IDENTIFIER,
        critical    BOOLEAN DEFAULT FALSE,
        extnValue   OCTET STRING  }

   The following items describe the X.509 v3 certificate for use in the
   Internet.

4.1.1  Certificate Fields

   The Certificate is a SEQUENCE of three required fields. The fields
   are described in detail in the following subsections.

4.1.1.1  tbsCertificate

   The field contains the names of the subject and issuer, a public key
   associated with the subject, a validity period, and other associated
   information.  The fields are described in detail in section 4.1.2;
   the tbscertificate may also include extensions which are described in
   section 4.2.

4.1.1.2  signatureAlgorithm

   The signatureAlgorithm field contains the identifier for the
   cryptographic algorithm used by the CA to sign this certificate.
   Section 7.2 lists the supported signature algorithms.

   An algorithm identifier is defined by the following ASN.1 structure:

   AlgorithmIdentifier  ::=  SEQUENCE  {
        algorithm               OBJECT IDENTIFIER,
        parameters              ANY DEFINED BY algorithm OPTIONAL  }

   The algorithm identifier is used to identify a cryptographic
   algorithm.  The OBJECT IDENTIFIER component identifies the algorithm
   (such as DSA with SHA-1).  The contents of the optional parameters
   field will vary according to the algorithm identified. Section 7.2
   lists the supported algorithms for this specification.

   This field MUST contain the same algorithm identifier as the
   signature field in the sequence tbsCertificate (see sec. 4.1.2.3).

4.1.1.3  signatureValue

   The signatureValue field contains a digital signature computed upon
   the ASN.1 DER encoded tbsCertificate.  The ASN.1 DER encoded
   tbsCertificate is used as the input to the signature function. This
   signature value is then ASN.1 encoded as a BIT STRING and included in
   the Certificate's signature field. The details of this process are
   specified for each of the supported algorithms in Section 7.2.

   By generating this signature, a CA certifies the validity of the
   information in the tbsCertificate field.  In particular, the CA
   certifies the binding between the public key material and the subject
   of the certificate.

4.1.2  TBSCertificate

   The sequence TBSCertificate contains information associated with the
   subject of the certificate and the CA who issued it.  Every
   TBSCertificate contains the names of the subject and issuer, a public
   key associated with the subject, a validity period, a version number,
   and a serial number; some may contain optional unique identifier
   fields.  The remainder of this section describes the syntax and
   semantics of these fields.  A TBSCertificate may also include
   extensions.  Extensions for the Internet PKI are described in Section
   4.2.

4.1.2.1  Version

   This field describes the version of the encoded certificate.  When
   extensions are used, as expected in this profile, use X.509 version 3
   (value is 2).  If no extensions are present, but a UniqueIdentifier
   is present, use version 2 (value is 1).  If only basic fields are
   present, use version 1 (the value is omitted from the certificate as
   the default value).

   Implementations SHOULD be prepared to accept any version certificate.
   At a minimum, conforming implementations MUST recognize version 3
   certificates.

   Generation of version 2 certificates is not expected by
   implementations based on this profile.

4.1.2.2  Serial number

   The serial number is an integer assigned by the CA to each
   certificate.  It MUST be unique for each certificate issued by a
   given CA (i.e., the issuer name and serial number identify a unique
   certificate).

4.1.2.3  Signature

   This field contains the algorithm identifier for the algorithm used
   by the CA to sign the certificate.

   This field MUST contain the same algorithm identifier as the
   signatureAlgorithm field in the sequence Certificate (see sec.
   4.1.1.2).  The contents of the optional parameters field will vary
   according to the algorithm identified.  Section 7.2 lists the
   supported signature algorithms.

4.1.2.4  Issuer

   The issuer field identifies the entity who has signed and issued the
   certificate.  The issuer field MUST contain a non-empty distinguished
   name (DN).  The issuer field is defined as the X.501 type Name.
   [X.501] Name is defined by the following ASN.1 structures:

   Name ::= CHOICE {
     RDNSequence }

   RDNSequence ::= SEQUENCE OF RelativeDistinguishedName

   RelativeDistinguishedName ::=
     SET OF AttributeTypeAndValue

   AttributeTypeAndValue ::= SEQUENCE {
     type     AttributeType,
     value    AttributeValue }

   AttributeType ::= OBJECT IDENTIFIER

   AttributeValue ::= ANY DEFINED BY AttributeType

   DirectoryString ::= CHOICE {
         teletexString           TeletexString (SIZE (1..MAX)),
         printableString         PrintableString (SIZE (1..MAX)),
         universalString         UniversalString (SIZE (1..MAX)),
         utf8String              UTF8String (SIZE (1.. MAX)),
         bmpString               BMPString (SIZE (1..MAX)) }

   The Name describes a hierarchical name composed of attributes, such
   as country name, and corresponding values, such as US.  The type of
   the component AttributeValue is determined by the AttributeType; in
   general it will be a DirectoryString.

   The DirectoryString type is defined as a choice of PrintableString,
   TeletexString, BMPString, UTF8String, and UniversalString.  The
   UTF8String encoding is the preferred encoding, and all certificates
   issued after December 31, 2003 MUST use the UTF8String encoding of
   DirectoryString (except as noted below).  Until that date, conforming
   CAs MUST choose from the following options when creating a
   distinguished name, including their own:

      (a) if the character set is sufficient, the string MAY be
      represented as a PrintableString;

      (b) failing (a), if the BMPString character set is sufficient the
      string MAY be represented as a BMPString; and

      (c) failing (a) and (b), the string MUST be represented as a
      UTF8String.  If (a) or (b) is satisfied, the CA MAY still choose
      to represent the string as a UTF8String.
*/


/* Unfinished, because they are almost certainly not required...

// Based on the Java API from U16 https://docs.oracle.com/javame/8.0/api/gcf/api/javax/microedition/pki/Certificate.html
getIssuer()        // Gets the name of this certificate's issuer.
getNotAfter()      // Gets the time after which this Certificate may not be used from the validity period.
getNotBefore()     // Gets the time before which this Certificate may not be used from the validity period.
getSerialNumber()  // Gets the printable form of the serial number of this Certificate.
getSigAlgName()    // Gets the name of the algorithm used to sign the Certificate.
getSubject()       // Gets the name of this certificate's subject.
getType()          // Get the type of the Certificate.
getVersion()       // Gets the version number of this Certificate.

// Gets the certificate's Organization Unit name ( ON ). 
U16 Certificate_getIssuerON( U8 *Certificate , U16 CertificateLength , U16 *OIDoffset, U16 *OIDlength )
{
   return( Certificate_getOID ( Certificate , length, &OID_id_at_organizationUnitName, &OIDoffset , &OIDlength ) );
}

// Gets the certificate's Common Name ( CN ). 
U16 Certificate_getIssuerON( U8 *Certificate , U16 CertificateLength , U16 *OIDoffset, U16 *OIDlength )
{
   return( Certificate_getOID ( Certificate , length, &OID_id_at_commonName, &OIDoffset , &OIDlength ) );
}

// Gets the time after which the certificate may not be used from the validity period.
U16 Certificate_getNotAfter( U8 *Certificate , U16 length , OID , OIDnumber , TagNumber )
{
   return( Certificate_getOID ( Certificate , length, &OID_id_at_organizationUnitName, &OIDoffset , &OIDlength ) );
}

// Gets the time before which the certificate may not be used from the validity period.
U16 Certificate_getNotBefore( U8 *Certificate , U16 length , OID , OIDnumber , TagNumber )
{
   return( Certificate_getOID ( Certificate , length, &OID_id_at_organizationUnitName, &OIDoffset , &OIDlength ) );
}

// Gets the printable form of the serial number of the certificate.
U16 Certificate_getSerialNumber( U8 *Certificate , U16 length , OID , OIDnumber , TagNumber )
{
   return( Certificate_getOID ( Certificate , length, &OID_id_at_organizationUnitName, &OIDoffset , &OIDlength ) );
}

// Gets the name of the algorithm used to sign the Certificate.
U16 Certificate_getSigAlgName( U8 *Certificate , U16 length , OID , OIDnumber , TagNumber )
{
   return( Certificate_getOID ( Certificate , length, &OID_id_at_organizationUnitName, &OIDoffset , &OIDlength ) );
}

// Gets the name of the certificate's subject.
U16 Certificate_getSubject( U8 *Certificate , U16 length , OID , OIDnumber , TagNumber )
{
   return( Certificate_getOID ( Certificate , length, &OID_id_at_organizationUnitName, &OIDoffset , &OIDlength ) );
}

// Get the type of the Certificate.
U16 Certificate_getType( U8 *Certificate , U16 length , OID , OIDnumber , TagNumber )
{
   return( Certificate_getOID ( Certificate , length, &OID_id_at_organizationUnitName, &OIDoffset , &OIDlength ) );
}

// Gets the version number of the certificate.
U16 getVersion( U8 *Certificate , U16 length , OID , OIDnumber , TagNumber )
{
   return( Certificate_getOID ( Certificate , length, &OID_id_at_organizationUnitName, &OIDoffset , &OIDlength ) );
}
*/
