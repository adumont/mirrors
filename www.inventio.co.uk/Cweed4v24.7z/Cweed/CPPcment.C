/* C++ comments to C style test file */
/* This line is commented using C syntax */
/*So is this line*/
// 1This line uses C++ syntax 
//2This line uses C++ syntax 
/* this is a block comment with // text in it
// so has this
*/ // this is not commented out
// Nor is this...
// bye for now! 
