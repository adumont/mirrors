readme.txt for ASN1DER.f 2015 Mar 12

\ ASN1DER.f  ASN.1 Abstract Syntax Notation version 1 Distinguished Encoding Rules 
\ Parse an X.509 Certificate that uses ASN.1 Abstract Syntax Notation version 1 and DER Distinguished Encoding Rules   

For each file e.g. MyCert.der that is read three files are created :
MyCert.txt    the certificate data in HexASCII format ( no CRs or LFs )
MyCert.Struct.txt    the certificate data in HexASCII format ( no CRs or LFs ) preceeded by a 
    16 bit Little Endian index number ( always = 5 ) and 16 bit Little Endian count,for TestStand
MyCert.c      the certificate data in C struct form.

The parsing algorithm has been converted into C in the files ParseCertificate.c and ParseCertificate.h

Source file only : run the SwiftForth console  ( double click on the SwiftForth link to sf.exe ) and type 

include ASN1DER.f <crlf>                                                  \ you can also type  tt <crlf>
ttSC1 <crlf>
loc ttSC1 <crlf>
g <crlf>

Enjoy!
Howerd 

www.inventio.co.uk
