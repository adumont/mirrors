USBclarify.f   V1.0 2014 May 18  Howerd Oakford  www.inventio.co.uk

Added 1 Sleep drop  to main loop to lower the drain on Windows
Added the USB device's serial number, with colour selected by MD5 hash, to maybe make it easier to see which device is which ( only 16 colours though... ).

Displays when a USB device is connected and disconnected, including which COM port a USB serial device is assigned to
Demonstrates how to use Windows device notifications 
Defines HID and other constants and structures, including support for GUIDs
Compile using SwiftForth, available from www.forth.com

The file usb.ids from http://www.linux-usb.org/usb.ids must be in the local folder in order to compile this program.
Thank you to the Linux guys for making this information available :-)
