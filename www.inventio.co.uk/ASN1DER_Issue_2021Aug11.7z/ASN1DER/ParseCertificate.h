//..begin "FILE DESCRIPTION"
//----------------------------------------------------------------------
//      (C) Copyright Landis+Gyr Enermet OY, CH-Zug & FI-Jysk�, 2007-2015
//      Use or copying of all or any part of the document, except
//      as permitted by the License Agreement is prohibited.
//----------------------------------------------------------------------
//
//      Purpose   : ANSI HeaderLocal File
//      Package   : ASN.1 Abstract Syntax Notation version 1 parser
//      File name : ParseCertificate.h
//      Status    :
//
//----------------------------------------------------------------------
//..end "FILE DESCRIPTION"

#ifndef __PARSECERTIFICATE_H__
#define __PARSECERTIFICATE_H__

// typedef unsigned char U8 ;
// typedef unsigned short U16 ;

U8 PayloadDataGetCh ( void );

U16 ASNoneGetLengthLimited ( void );

void SkipValue ( void );

void GetTagAndLength( void );

void GetNextTLV( void );  

void GetTagLengthValue ( U8 * RequiredOID );

U16 Certificate_getOID( U8 * Certificate , U16 CertificateLength , U8 *RequiredOID , U16 *OIDoffset, U16 *OIDlength , U16 SkipOctets );

extern U16 Certificate_getPublicKey( U8 *Certificate , U16 CertificateLength , U16 *OIDoffset, U16 *OIDlength );

extern U16 Certificate_getAuthorityKeyIdentifier( U8 *Certificate , U16 CertificateLength , U16 *OIDoffset, U16 *OIDlength );

extern void TestParseCertificate( void );

#endif // __PARSECERTIFICATE_H__
