readme.txt colorForth cf2009 Howerd Oakford 2009 May 15

Quick start guide
=================
Put a blank, formatted floppy disk in the floppy drive and double click on "go.bat"
This will create a bootable colorForth floppy disk
Reboot your computer with the floppy in the drive
You may need to adjust your BIOS settings to get the floppy to boot -
please see http://www.inventio.co.uk/getbios.htm from http://www.inventio.co.uk/cfdos.htm for how to do this...
Note : this version requires a built-in floppy drive - it will not work from an external USB drive.

Details
=======
The 256K binary image cf2009.blk is created from COLOR.COM ( 12K ) concatenated 
with ICONS.FNT ( 6K ) and CFDOS4CF.BLK ( 238K ).

COLOR.COM	colorForth system
ICONS.FNT	character icons	( blocks 12 to 17 from CFDOS4BLK )	
CFDOS4CF.BLK	colorForth source ( blocks 18 to 255 from CFDOS4BLK )
Note that just as in the CFDOS4.BLK release, the last 4 blocks are not saved/restored
by the colorForth system - so don't use them! ( 14 sectors x 18K = 252K ).

COLOR.COM is assembled from color.asm , boot.asm and gen.asm by DOS batch file go.bat.
MASM is included here for this purpose.
color.asm	colorForth system
boot.asm	floppy disk boot 
gen.asm		generic video display using a VESA call

The files are from Chuck Moore's 2001 Jul 22 release, which include modifications to
the floppy disk code by Terry Loveall and Kris Johnstone.

I ( Howerd ) have made some small changes to merge with my CFDOS4.BLK release.
1. changed the version number in the boot sector
2. changed the assembler output length to 12K
3. changed the go.bat file to merge color.com, icons.fnt and cfdos4cf.blk 
4. added  floppy.com to download automatically to the floppy disk

"Modified from the orginal written by Chuck Moore. Thanks Chuck, nice job!"
I second that! 
Enjoy!!!

Howerd  8^)

howerd@inventio.co.uk  www.inventio.co.uk


From the original readme.txt file :

Readme for colorForth on an Asus P2B-D motherboard.
 Modified from the orginal written by Chuck Moore. Thanks Chuck, nice job!
 07/19/01 Terry Loveall    loveall@qwest.net
 07/22/01 Kris Johnson     kristopher_d_johnson@yahoo.com

THIS SOFTWARE COMES WITH NO WARRANTY. USE AT YOUR OWN RISK.

The floppy modifications were derived from examination of the BIOS
 int 13 code. They are empirically determined and work on my (TL's)
 system.  Your Mileage May Vary.

TL's system is an Asus P2B-D dual PII 450 Mhz motherboard. It uses the
 440BX chipset, a Winbond W83977tf super I/O chip and PII4XE PCIset
 (Southbridge, I think).

The modified source for the floppy is located mainly in boot.asm. It
 consists of adding a write strobe to IO address 0E1h to all I/O to
 the floppy controller at IO address range 03F0h. This additional 
 code expanded the boot sector to a size larger than 512 bytes, which 
 necessitated a re-structuring of the boot sector code. The 
 'call stop, call dma' code was moved from boot.asm to the 'start1' 
 label in color.asm

For color forth operation and programming see http://colorforth.com/.
 
