namespace {
/* comment */
void MyFunction( int fred ) /* COMMENT */
{
    {
    }
}
}
/* hello */

/* ... *