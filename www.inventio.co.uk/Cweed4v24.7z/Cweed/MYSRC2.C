/*****************************************************************************/
/*
*
*/

> go away
> and you

GLOBAL_FUNC t_void SpecialFunction(
       t_type (*myname) (int a, char b),
    volatile  t_type * const  * * ( * m) ( int  a ,  char  b),
    (*t_byte*)                **source_pptr,
 "OFF"                     **source_pptr,
   $var                      **source_pptr,
    &fun                       **source_pptr,
    t_byte                    **source_pptr(* fred)
    const t_byte              **source_pptr,
    t_byte *const *const       *fred,
    t_b *const *const        *(*foo)
    volatile t_word          ***another_ppptr,
    const t_w *const           *another_ptr,
    t_colour restrict          *block_start_ptr,
    const t_extent             *block_size_ptr,
    t_dimension                 frame_width,
    e_enumeratorverylongname     format)
{
    {
        t_colour pixel;
    }
}
